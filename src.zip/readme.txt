Can be run by loading the main.m script into MatLab and running the script.

